// Variabler 
let change = "Ändringsbar variabel";
const constant = "Konstant variabel, går inte att ändra.";

